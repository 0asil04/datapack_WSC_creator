
export interface Club {
  id: string;
  name: string;
}

export interface CsvRow {
  id: string;
  values: string;
}
